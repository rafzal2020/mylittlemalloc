# mylittlemalloc
CS214 Project 1


# Collaborators
Rayaan Afzal (ra965)

Anthony Rahner (arr234)


# Test Programs
memgrind.c

memtest.c (default test program included with project folder)

memtest2.c (tests if malloc() reserves unallocated memory)

memtest3.c (tests if free() deallocates memory)

memtest4.c (test for proper coalescing)

memtest5.c (test the edge cases from section 2 of the writeup)

memtest6.c (tests leak detection)
