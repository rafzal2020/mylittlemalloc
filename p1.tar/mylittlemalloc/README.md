# mylittlemalloc
CS214 Project 1


# Collaborators
Rayaan Afzal (ra965)

Anthony Rahner (arr234)


# Test Programs (so far)
memgrind.c
